package com.chargingstudio.app.charging

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.chargingstudio.app.animation.AnimationRepository
import com.chargingstudio.app.aod.AodOverlayService

class ChargeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                val mode = AnimationRepository.getActiveMode(context)
                when (mode) {
                    "animation" -> startService(context, ChargingOverlayService::class.java)
                    "aod" -> startService(context, AodOverlayService::class.java)
                }
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                context.stopService(Intent(context, ChargingOverlayService::class.java))
                context.stopService(Intent(context, AodOverlayService::class.java))
            }
        }
    }

    private fun startService(context: Context, cls: Class<*>) {
        val i = Intent(context, cls)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(i)
        } else {
            context.startService(i)
        }
    }
}
